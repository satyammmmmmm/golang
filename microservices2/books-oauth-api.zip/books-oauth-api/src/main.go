package main

import "oauth/app"

func main() {
	app.StartApp()
}
